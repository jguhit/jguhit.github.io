from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from ETH_CMD_BASE import *
from StyleSheet import *
import time
import datetime


class eth_rx(object):
    """docstring for eth_rx"""

    def __init__(self, eth):
        self.eth = eth
        self.processing = False
        self.time_total = 0
        self.time_last = 0
        self.total_packet = 0

    def setupUi(self, MainWindow):
        self.gridLayoutWidget = QtWidgets.QWidget(MainWindow)
        self.gridLayoutWidget.setGeometry(QtCore.QRect(0, 0, 200, 300))
        self.gridLayout = QtWidgets.QGridLayout(self.gridLayoutWidget)
        self.label_vio_list = []
        # for i in range (47):
        #     label = QtWidgets.QLabel("0", self.gridLayoutWidget)


        label = QtWidgets.QLabel("sem_heartbeat", self.gridLayoutWidget)
        self.gridLayout.addWidget(label, 0, 0, 1, 1)

        self.label_sem_heartbeat_led = QtWidgets.QLabel()
        self.gridLayout.addWidget(self.label_sem_heartbeat_led, 0, 1, 1, 1)
        self.label_sem_heartbeat_led.setStyleSheet(LedGray)
        self.label_vio_list.append(self.label_sem_heartbeat_led)

        label = QtWidgets.QLabel("sem_fatalerr", self.gridLayoutWidget)
        self.gridLayout.addWidget(label, 1, 0, 1, 1)
        self.label_sem_fatalerr_led = QtWidgets.QLabel()
        self.gridLayout.addWidget(self.label_sem_fatalerr_led, 1, 1, 1, 1)
        self.label_sem_fatalerr_led.setStyleSheet(LedGray)
        self.label_sem_fatalerr_led.setText('0')
        self.label_vio_list.append(self.label_sem_fatalerr_led)

        label = QtWidgets.QLabel("design_number", self.gridLayoutWidget)
        self.gridLayout.addWidget(label, 2, 0, 1, 1)
        self.label = QtWidgets.QLabel("", self.gridLayoutWidget)
        self.gridLayout.addWidget(self.label, 2, 1, 1, 1)
        self.label_vio_list.append(self.label)


        label = QtWidgets.QLabel("locked_vio", self.gridLayoutWidget)
        self.gridLayout.addWidget(label, 3, 0, 1, 1)
        self.label_locked_vio_led = QtWidgets.QLabel()
        self.gridLayout.addWidget(self.label_locked_vio_led, 3, 1, 1, 1)
        self.label_locked_vio_led.setStyleSheet(LedGray)
        self.label_locked_vio_led.setText('1')
        self.label_vio_list.append(self.label_locked_vio_led)

        label = QtWidgets.QLabel("elink_TTCin_err", self.gridLayoutWidget)
        self.gridLayout.addWidget(label, 4, 0, 1, 1)        



        for i in range (0,6):
            label = QtWidgets.QLabel(str(5-i), self.gridLayoutWidget)
            self.gridLayout.addWidget(label, i+5, 0, 1, 1)
            self.label = QtWidgets.QLabel("", self.gridLayoutWidget)
            self.gridLayout.addWidget(self.label, i+5, 1, 1, 1)
            self.label_vio_list.append(self.label)

        self.gridLayoutWidget4 = QtWidgets.QWidget(MainWindow)
        self.gridLayoutWidget4.setGeometry(QtCore.QRect(0, 300, 300, 100))
        self.gridLayout4 = QtWidgets.QGridLayout(self.gridLayoutWidget4)

        self.pushButton_startEth = QtWidgets.QPushButton()
        self.pushButton_startEth.setText("Start eth")
        self.gridLayout4.addWidget(self.pushButton_startEth, 0, 0, 1, 1)
        # self.pushButton_startEth.clicked.connect(self.vio_update)
        self.pushButton_startEth.clicked.connect(self.start_monitor)      

        self.pushButton_stopEth = QtWidgets.QPushButton()
        self.pushButton_stopEth.setText("Stop eth")
        self.gridLayout4.addWidget(self.pushButton_stopEth, 0, 1, 1, 1)
        self.pushButton_stopEth.clicked.connect(self.stop_monitor)

        self.pushButton_clear_timer = QtWidgets.QPushButton()
        self.pushButton_clear_timer.setText("Clear all")
        self.gridLayout4.addWidget(self.pushButton_clear_timer,0,2,1,1)
        self.pushButton_clear_timer.clicked.connect(self.clear_timer)

        # time elapsed
        self.label = QtWidgets.QLabel()
        self.label.setText("Time elapsed total")
        self.gridLayout4.addWidget(self.label, 1, 0, 1, 1)

        self.label_time_total = QtWidgets.QLabel()
        self.label_time_total.setText("0:00:00")
        self.gridLayout4.addWidget(self.label_time_total, 1, 1, 1, 1)

        self.label = QtWidgets.QLabel()
        self.label.setText("Last time")
        self.gridLayout4.addWidget(self.label, 2, 0, 1, 1)

        self.label_time_last = QtWidgets.QLabel()
        self.label_time_last.setText("0:00:00")
        self.gridLayout4.addWidget(self.label_time_last, 2, 1, 1, 1)

        self.gridLayoutWidget2 = QtWidgets.QWidget(MainWindow)
        self.gridLayoutWidget2.setGeometry(QtCore.QRect(300, 0, 500, 400))
        self.gridLayout2 = QtWidgets.QGridLayout(self.gridLayoutWidget2)

        label = QtWidgets.QLabel("TDO err", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(label, 0, 0, 1, 1)

        label = QtWidgets.QLabel("tck_err", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(label, 1, 1, 1, 1)

        label = QtWidgets.QLabel("tms_err", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(label, 1, 2, 1, 1)

        label = QtWidgets.QLabel("tck_err", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(label, 1, 5, 1, 1)

        label = QtWidgets.QLabel("tms_err", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(label, 1, 6, 1, 1)

        for i in range(0, 18):
            if i<9:
                label = QtWidgets.QLabel('reg'+str(17 - i), self.gridLayoutWidget2)
                self.gridLayout2.addWidget(label, 2 + i, 0, 1, 1)
            else:
                label = QtWidgets.QLabel('reg'+str(17 - i), self.gridLayoutWidget2)
                self.gridLayout2.addWidget(label, 2 + i-9, 4, 1, 1)

        # tck error
        for i in range(0, 18):
            if i<9:
                self.label = QtWidgets.QLabel('', self.gridLayoutWidget2)
                self.gridLayout2.addWidget(self.label, 2 + i, 1, 1, 1)
            else:
                self.label = QtWidgets.QLabel('', self.gridLayoutWidget2)
                self.gridLayout2.addWidget(self.label, 2 + i-9, 5, 1, 1)
            self.label_vio_list.append(self.label)

        # tms error
        for i in range(0, 18):
            if i<9:
                self.label = QtWidgets.QLabel('', self.gridLayoutWidget2)
                self.gridLayout2.addWidget(self.label, 2 + i, 2, 1, 1)
            else:
                self.label = QtWidgets.QLabel('', self.gridLayoutWidget2)
                self.gridLayout2.addWidget(self.label, 2 + i-9, 6, 1, 1)
            self.label_vio_list.append(self.label)

        #tdo error
        self.label = QtWidgets.QLabel("", self.gridLayoutWidget2)
        self.gridLayout2.addWidget(self.label, 0, 1, 1, 1)
        self.label_vio_list.append(self.label)

        print(len(self.label_vio_list))

    def vio_update(self):
        self.total_packet += 1
        # print('singal connect success!')
        if 0<self.total_packet<10 or self.total_packet%100==0:
            print("Received "+str(self.total_packet) +" packets!")
        if 9<self.total_packet<100 and self.total_packet%10==0:
            print("Received "+str(self.total_packet) +" packets!")

        self.label_vio_list[0]. setStyleSheet(LedGreen if self.eth.error_list[0]=='1' else LedGray)

        # print('fatal error label text = '+self.label_vio_list[1].text())
        # print('fatal error reg = '+self.eth.error_list[1])
        if self.label_vio_list[1].text()=='0' and self.eth.error_list[1]=='1': 
            print("---FATAL ERROR!!---") 
        self.label_vio_list[1].setText(self.eth.error_list[1])
        self.label_vio_list[1].setStyleSheet(LedRed if self.eth.error_list[1]=='1' else LedGray)
        self.label_vio_list[3].setStyleSheet(LedGreen if self.eth.error_list[3] == '1' else LedGray)
        self.label_time_last.setText(str(datetime.timedelta(seconds=self.time_last))[:7])
        self.label_time_total.setText(str(datetime.timedelta(seconds=self.time_total))[:7])      
        for i in range (2,47):
            if self.eth.error_list[i]!=self.label_vio_list[i].text():                                     
                if i==2:
                    self.label_vio_list[2]. setText(self.eth.error_list[2])
                    print('design number changed to '+self.eth.error_list[2])
                if i==3:
                    self.label_vio_list[i].setText(self.eth.error_list[i])
                    print('vio locked' if self.eth.error_list[3]=='1' else 'vio unlocked')
                if 3<i<10:
                    self.label_vio_list[i].setText(self.eth.error_list[i])
                    print('TTCin_err_reg_'+str(9-i)+'='+self.eth.error_list[i])
                if 9<i<28:    
                    self.label_vio_list[i].setText(self.eth.error_list[i])
                    print('TCK_err_reg_'+str(27-i)+'='+self.eth.error_list[i])
                if 27<i<46:
                    self.label_vio_list[i].setText(self.eth.error_list[i])
                    print('TMS_err_reg_'+str(45-i)+'='+self.eth.error_list[i])
                if i==46:
                    self.label_vio_list[i].setText(self.eth.error_list[i])
                    print('TDO_err_reg='+self.eth.error_list[i])    

    def start_monitor(self):    

        # Step 2: Create a QThread object
        self.thread = QThread()
        # Step 3: Create a worker object
        self.worker = Worker_eth_read(self)
        # Step 4: Move worker to the thread
        self.worker.moveToThread(self.thread)
        # Step 5: Connect signals and slots
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        # Step 6: Start the thread
        self.thread.start()
        self.pushButton_startEth.setEnabled(False)
        self.pushButton_clear_timer.setEnabled(False)
        self.thread.finished.connect(lambda: self.pushButton_startEth.setEnabled(True))
        self.thread.finished.connect(lambda: self.pushButton_clear_timer.setEnabled(True))

        self.worker.update_GUI.connect(self.vio_update)


        # Step 2: Create a QThread object
        self.thread2 = QThread()
        # Step 3: Create a worker object
        self.worker2 = Worker_find_tdo(self)
        # Step 4: Move worker to the thread
        self.worker2.moveToThread(self.thread2)
        # Step 5: Connect signals and slots
        self.thread2.started.connect(self.worker2.run)
        self.worker2.finished.connect(self.thread2.quit)
        self.worker2.finished.connect(self.worker2.deleteLater)
        self.thread2.finished.connect(self.thread2.deleteLater)
        # Step 6: Start the thread
        self.thread2.start()

        

    def stop_monitor(self):
        self.processing = False  

    def clear_timer(self):
        self.time_total = 0
        self.time_last = 0
        self.total_packet = 0
        self.label_time_total.setText("0:00:00")
        self.label_time_last.setText("0:00:00")

 
class Worker_eth_read(QObject):
    """docstring for Worker"""

    finished = pyqtSignal()
    update_GUI = pyqtSignal()

    def __init__(self, eth_rx):
        super(Worker_eth_read, self).__init__()
        self.eth_rx = eth_rx


    def run(self):   
        self.eth_rx.time_last = 0   
        self.eth_rx.processing = True        
        time_accu =  self.eth_rx.time_total
        # crc_cal_tmp = crc_cal(self.eth_rx.TDC_inst)  
        print("Monitoring error counters!") 
        start = time.time()
        while self.eth_rx.processing:
            packet_full = ethread(self.eth_rx.eth.eth_name)
            decode_success = self.eth_rx.eth.vio_decode(packet_full)
            if decode_success==1:
                self.update_GUI.emit()           
            end = time.time()
            self.eth_rx.time_last = end-start
            self.eth_rx.time_total = time_accu + self.eth_rx.time_last
        print("Monitoring stopped.")
        print("Monitoring time: " +str(end-start))
        self.finished.emit()


class Worker_find_tdo(QObject):
    """docstring for Worker"""

    finished = pyqtSignal()


    def __init__(self, eth_rx):
        super(Worker_find_tdo, self).__init__()
        self.eth_rx = eth_rx
        self.tdo_error = int(self.eth_rx.eth.error_list[46])
        self.tdo_error_pre = int(self.eth_rx.eth.error_list[46])

    def run(self): 
        time.sleep(2)  # wait for first packet to be received
        while self.eth_rx.processing:
            self.tdo_error_pre = self.tdo_error
            self.tdo_error = int(self.eth_rx.eth.error_list[46])
            # print('tdo_error='+str(self.tdo_error))
            # print('tdo_error_pre='+str(self.tdo_error_pre))
            time.sleep(1)  #  qt timer
            self.tdo_error_pre = self.tdo_error
            self.tdo_error = int(self.eth_rx.eth.error_list[46])
            # print('tdo_error='+str(self.tdo_error))
            # print('tdo_error_pre='+str(self.tdo_error_pre))
            if self.tdo_error-self.tdo_error_pre>10000:
                print('tdo_error='+str(self.tdo_error))
                print('tdo_error_pre='+str(self.tdo_error_pre))
                print("TDO link failed! Now start to check.")
                jtag_working_chain = ''
                for i in range (18):
                    if self.eth_rx.processing:
                        jtag_daisy_chain = ''                    
                        for j in range (18):
                            jtag_daisy_chain += '1' if i==j else '0'
                        print(jtag_daisy_chain)
                        self.eth_rx.eth.jtag_daisychain[0]=jtag_daisy_chain
                        self.eth_rx.eth.update_VIO_CONTROL()
                        time.sleep(1)
                        self.tdo_error_pre = self.tdo_error
                        self.tdo_error = int(self.eth_rx.eth.error_list[46])
                        time.sleep(1)
                        self.tdo_error_pre = self.tdo_error
                        self.tdo_error = int(self.eth_rx.eth.error_list[46])
                        jtag_working_chain += '1' if self.tdo_error==self.tdo_error_pre else '0'
                jtag_daisy_chain = '000000000000000000'
                print("jtag_working_chain="+jtag_working_chain)
                self.eth_rx.eth.jtag_daisychain[0]=jtag_daisy_chain
                self.eth_rx.eth.update_VIO_CONTROL()
            time.sleep(1)
        self.finished.emit()



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    eth = ETH_control()
    ui = eth_rx(eth)
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
        
