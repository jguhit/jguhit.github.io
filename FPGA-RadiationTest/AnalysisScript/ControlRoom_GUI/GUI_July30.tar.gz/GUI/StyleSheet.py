LedRed ='''background-color: red;
        border-style: solid;
        border-width:0px;
        border-radius:6px;
        max-width: 12px;
        max-height:12px;
        min-width: 12px;
        min-height:12px;'''
LedGreen ='''background-color: green;
        border-style: solid;
        border-width:0px;
        border-radius:6px;
        max-width: 12px;
        max-height:12px;
        min-width: 12px;
        min-height:12px;'''

LedGray ='''background-color: gray;
        border-style: solid;
        border-width:0px;
        border-radius:6px;
        max-width: 12px;
        max-height:12px;
        min-width: 12px;
        min-height:12px;'''